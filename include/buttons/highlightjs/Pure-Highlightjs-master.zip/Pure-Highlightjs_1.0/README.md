# Pure-Highlightjs

A lightweight syntax highlighter for WordPress

## Dependents

[highlight.js](https://highlightjs.org/ "highlight.js")

## License

The MIT License.

Copyright (c) 2016 iCodeChef